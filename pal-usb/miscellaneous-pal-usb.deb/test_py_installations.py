import os
import sys
import ast
import collections
import copy
import glob
import time
import random
import numpy as np

sys.path.append('/opt/ros/melodic/lib/python2.7/dist-packages')
sys.path.remove('/opt/ros/melodic/lib/python2.7/dist-packages')

print('')
print('[INFO] Python Installations Successfull')
